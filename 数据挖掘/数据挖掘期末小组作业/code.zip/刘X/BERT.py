import os
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import classification_report, f1_score
from tqdm import tqdm

from modelscope import AutoTokenizer, AutoModelForMaskedLM


# =====================
# 配置
# =====================
MODEL_ID = "google-bert/bert-base-chinese"
MAX_LEN = 128
BATCH_SIZE = 16*8
EPOCHS = 3
N_FOLDS = 5
LR = 2e-5
NUM_LABELS = 2

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
os.makedirs("result", exist_ok=True)


# =====================
# Dataset
# =====================
class BertDataset(Dataset):
    def __init__(self, texts, labels, tokenizer):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = str(self.texts[idx])

        encoded = self.tokenizer(
            text,
            max_length=MAX_LEN,
            padding="max_length",
            truncation=True,
            return_tensors="pt"
        )

        item = {
            "input_ids": encoded["input_ids"].squeeze(0),
            "attention_mask": encoded["attention_mask"].squeeze(0)
        }

        if self.labels is not None:
            item["labels"] = torch.tensor(self.labels[idx], dtype=torch.long)

        return item


# =====================
# 模型：MLM + 分类头
# =====================
class BertForTextClassification(nn.Module):
    def __init__(self, bert_mlm, hidden_size=768, num_labels=2):
        super().__init__()
        self.bert = bert_mlm.bert   # 只用 encoder
        self.dropout = nn.Dropout(0.1)
        self.classifier = nn.Linear(hidden_size, num_labels)

    def forward(self, input_ids, attention_mask, labels=None):
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            return_dict=True
        )

        cls_output = outputs.last_hidden_state[:, 0]  # [CLS]
        cls_output = self.dropout(cls_output)
        logits = self.classifier(cls_output)

        loss = None
        if labels is not None:
            loss_fn = nn.CrossEntropyLoss()
            loss = loss_fn(logits, labels)

        return loss, logits


# =====================
# Train / Predict
# =====================
def train_one_epoch(model, loader, optimizer):
    model.train()
    total_loss = 0.0

    for batch in tqdm(loader, leave=False):
        optimizer.zero_grad()

        input_ids = batch["input_ids"].to(DEVICE)
        attention_mask = batch["attention_mask"].to(DEVICE)
        labels = batch["labels"].to(DEVICE)

        loss, _ = model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            labels=labels
        )

        loss.backward()
        optimizer.step()
        total_loss += loss.item()

    return total_loss / len(loader)


def predict(model, loader):
    model.eval()
    logits_all = []
    labels_all = []

    with torch.no_grad():
        for batch in tqdm(loader, leave=False):
            input_ids = batch["input_ids"].to(DEVICE)
            attention_mask = batch["attention_mask"].to(DEVICE)
            labels = batch.get("labels")

            _, logits = model(
                input_ids=input_ids,
                attention_mask=attention_mask
            )

            logits_all.append(logits.cpu().numpy())

            if labels is not None:
                labels_all.append(labels.numpy())

    logits_all = np.vstack(logits_all)
    if labels_all:
        return logits_all, np.concatenate(labels_all)
    return logits_all, None


# =====================
# Main
# =====================
def main():
    # ---------- Data ----------
    train_df = pd.read_csv("data/train.csv", sep="\t")
    test_df = pd.read_csv("data/test_new.csv")
    sub = pd.read_csv("data/sample.csv")

    texts = train_df["comment"].astype(str).values
    labels = train_df["label"].values
    test_texts = test_df["comment"].astype(str).values

    # ---------- Tokenizer & Model ----------
    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
    base_mlm = AutoModelForMaskedLM.from_pretrained(MODEL_ID)

    skf = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=52)

    oof_logits = np.zeros((len(train_df), NUM_LABELS))
    test_logits = np.zeros((len(test_df), NUM_LABELS))

    for fold, (tr_idx, val_idx) in enumerate(skf.split(texts, labels)):
        print(f"\n========== Fold {fold + 1} ==========")

        model = BertForTextClassification(
            bert_mlm=base_mlm,
            hidden_size=768,
            num_labels=NUM_LABELS
        ).to(DEVICE)

        optimizer = torch.optim.AdamW(model.parameters(), lr=LR)

        train_loader = DataLoader(
            BertDataset(texts[tr_idx], labels[tr_idx], tokenizer),
            batch_size=BATCH_SIZE,
            shuffle=True
        )

        val_loader = DataLoader(
            BertDataset(texts[val_idx], labels[val_idx], tokenizer),
            batch_size=BATCH_SIZE
        )

        test_loader = DataLoader(
            BertDataset(test_texts, None, tokenizer),
            batch_size=BATCH_SIZE
        )

        for epoch in range(EPOCHS):
            loss = train_one_epoch(model, train_loader, optimizer)
            print(f"Epoch {epoch + 1}/{EPOCHS}, Loss: {loss:.4f}")

        val_logits, _ = predict(model, val_loader)
        oof_logits[val_idx] = val_logits

        test_fold_logits, _ = predict(model, test_loader)
        test_logits += test_fold_logits

    # ---------- Evaluation ----------
    oof_pred = np.argmax(oof_logits, axis=1)
    print("\n===== OOF =====")
    print(classification_report(labels, oof_pred))
    print("F1:", f1_score(labels, oof_pred))

    test_pred = np.argmax(test_logits, axis=1)
    sub["label"] = test_pred
    sub.to_csv("result/bert_modelscope.csv", index=False)
    print("\nSaved: result/bert_modelscope.csv")


if __name__ == "__main__":
    main()
