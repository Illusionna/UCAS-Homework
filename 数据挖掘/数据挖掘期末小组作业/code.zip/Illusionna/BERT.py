import os
import shutil
import platform
import warnings

warnings.filterwarnings('ignore', category = UserWarning, module = 'jieba')

import tqdm
import jieba
import torch
import pandas as pd
import transformers
import sklearn.metrics
import sklearn.model_selection


EPOCHS = 32
MAX_LEN = 128
BATCH_SIZE = 512
LEARNING_RATE = 2e-5
DEVICE = torch.device('mps' if platform.system() == 'Darwin' else 'cuda:7' if torch.cuda.is_available() else 'cpu')


def cls() -> None:
    jieba.setLogLevel(jieba.logging.INFO)
    transformers.logging.set_verbosity_error()
    os.system('')
    for root, dirs, files in os.walk(os.getcwd()):
        for dir in dirs:
            if dir == '__pycache__':
                shutil.rmtree(os.path.join(root, dir))
        for file in files:
            if file == '.DS_Store':
                os.remove(os.path.join(root, file))
    try:
        os.system(
            {'Windows': 'cls', 'Linux': 'clear', 'Darwin': 'clear'}[platform.system()]
        )
    except:
        print('\x1b[H\x1b[J', end = '')
cls()


class O2ODataset(torch.utils.data.Dataset):
    def __init__(self, texts, labels=None, tokenizer=None, max_len=MAX_LEN):
        super().__init__()
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_len = max_len

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        text = str(self.texts[idx])
        encoding = self.tokenizer.encode_plus(
            text,
            add_special_tokens=True,
            max_length=self.max_len,
            padding='max_length',
            truncation=True,
            return_token_type_ids=False,
            return_attention_mask=True,
            return_tensors='pt',
        )

        item = {
            'input_ids': encoding['input_ids'].flatten(),
            'attention_mask': encoding['attention_mask'].flatten()
        }

        if self.labels is not None:
            item['labels'] = torch.tensor(self.labels[idx], dtype=torch.long)

        return item


train_df = pd.read_csv('./dataset/train.csv', sep='\t').fillna('')
test_df = pd.read_csv('./dataset/test.csv', sep=',').fillna('')

X_train, X_val, y_train, y_val = sklearn.model_selection.train_test_split(train_df['comment'], train_df['label'], test_size=0.01)

PRETRAINED_MODEL = 'bert-base-chinese'
tokenizer = transformers.BertTokenizer.from_pretrained(PRETRAINED_MODEL, cache_dir='bert_cache')

train_dataset = O2ODataset(X_train.to_numpy(), y_train.to_numpy(), tokenizer)
val_dataset = O2ODataset(X_val.to_numpy(), y_val.to_numpy(), tokenizer)
test_dataset = O2ODataset(test_df['comment'].to_numpy(), None, tokenizer)

train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=BATCH_SIZE)
test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=BATCH_SIZE)

model = transformers.BertForSequenceClassification.from_pretrained(PRETRAINED_MODEL, num_labels=2, cache_dir='bert_cache')
model = model.to(DEVICE)
optimizer = torch.optim.AdamW(model.parameters(), lr=LEARNING_RATE)


best_f1 = 0.0
for epoch in range(EPOCHS):
    model.train()
    total_loss = 0
    train_loop = tqdm.tqdm(train_loader, desc=f'Epoch {epoch+1}/{EPOCHS}')
    for batch in train_loop:
        input_ids = batch['input_ids'].to(DEVICE)
        attention_mask = batch['attention_mask'].to(DEVICE)
        labels = batch['labels'].to(DEVICE)
        optimizer.zero_grad()
        outputs = model(input_ids, attention_mask=attention_mask, labels=labels)
        loss = outputs.loss
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
        train_loop.set_postfix(loss=loss.item())
    avg_train_loss = total_loss / len(train_loader)

    model.eval()
    val_preds = []
    val_labels = []
    with torch.no_grad():
        for batch in val_loader:
            input_ids = batch['input_ids'].to(DEVICE)
            attention_mask = batch['attention_mask'].to(DEVICE)
            labels = batch['labels'].to(DEVICE)
            outputs = model(input_ids, attention_mask=attention_mask)
            _, preds = torch.max(outputs.logits, dim=1)
            val_preds.extend(preds.cpu().numpy())
            val_labels.extend(labels.cpu().numpy())
    current_f1 = sklearn.metrics.f1_score(val_labels, val_preds, average='macro')
    print(f"  -> Train Loss: {avg_train_loss:.4f} | Val F1: {current_f1:.4f}")
    if current_f1 > best_f1:
        best_f1 = current_f1
        torch.save(model.state_dict(), 'best_model.pth')
        print(f"  -> F1 分数提升至 {best_f1:.4f}，模型已保存")
    print("-" * 50)

print(f"\n正在加载最佳模型 (Best F1: {best_f1:.4f}) 进行预测...")
model.load_state_dict(torch.load('best_model.pth'))
model.eval()

predictions = []
with torch.no_grad():
    test_loop = tqdm.tqdm(test_loader, desc='Testing')
    for batch in test_loop:
        input_ids = batch['input_ids'].to(DEVICE)
        attention_mask = batch['attention_mask'].to(DEVICE)
        outputs = model(input_ids, attention_mask=attention_mask)
        _, preds = torch.max(outputs.logits, dim=1)
        predictions.extend(preds.cpu().tolist())

submission = pd.DataFrame({'id': test_df['id'], 'label': predictions})
submission.to_csv('submission_bert.csv', index=False)
print("BERT 预测文件已生成")