import os
import shutil
import platform
import warnings

warnings.filterwarnings('ignore', category = UserWarning, module = 'jieba')
warnings.filterwarnings('ignore', category = UserWarning, module = 'sklearn')

import jieba
import pandas as pd
import sklearn.metrics
import sklearn.pipeline
import sklearn.model_selection
import sklearn.feature_extraction

import sklearn.linear_model
import sklearn.naive_bayes
import sklearn.ensemble
import sklearn.tree
import sklearn.svm


def cls() -> None:
    jieba.setLogLevel(jieba.logging.INFO)
    os.system('')
    for root, dirs, files in os.walk(os.getcwd()):
        for dir in dirs:
            if dir == '__pycache__':
                shutil.rmtree(os.path.join(root, dir))
        for file in files:
            if file == '.DS_Store':
                os.remove(os.path.join(root, file))
    try:
        os.system(
            {'Windows': 'cls', 'Linux': 'clear', 'Darwin': 'clear'}[platform.system()]
        )
    except:
        print('\x1b[H\x1b[J', end = '')
cls()


def progress_bar(current: int, total: int, step: int = 1, description: str = None) -> None:
    if (current + 1) != 0 and (current + 1) % step != 0 and (current + 1) != total: return
    width = 50
    print('\x1b[?25l', end = '')
    percentage = (current + 1) / total
    filled = int(percentage * width)
    if description: print(f'\r{description}  [', end = '') 
    else: print(f'\r[', end = '')
    for i in range(0, width, 1):
        if i < filled: print('\x1b[32m=\x1b[0m', end = '')
        elif i == filled: print('>', end = '')
        else: print(' ', end = '')
    print('] %7.2f%%  (%d/%d)' % (percentage * 100, current + 1, total), end = '')
    if current + 1 >= total:
        print('\x1b[?25h')


def read_dataset() -> tuple:
    df = pd.read_csv(filepath_or_buffer = os.path.join('dataset', 'train.csv'), sep = '\t')
    comment = df['comment']
    label = df['label']
    train_comment, valid_comment, train_label, valid_label = sklearn.model_selection.train_test_split(comment, label, train_size = 0.8, random_state = 42)
    return train_comment, valid_comment, train_label, valid_label


def evaluate(true_value: list, prediction_value: list) -> dict:
    accuracy = sklearn.metrics.accuracy_score(true_value, prediction_value)
    precision = sklearn.metrics.precision_score(true_value, prediction_value, zero_division = 0)
    recall = sklearn.metrics.recall_score(true_value, prediction_value, zero_division = 0)
    f1 = sklearn.metrics.f1_score(true_value, prediction_value, zero_division = 0)
    return {'accuracy': accuracy, 'precision': precision, 'recall': recall, 'f1': f1}


def train() -> None:
    vectorizers = {
        'TFIDF': sklearn.feature_extraction.text.TfidfVectorizer(tokenizer = lambda text: list(jieba.cut(text))),
        'CountVectorizer': sklearn.feature_extraction.text.CountVectorizer(tokenizer = lambda text: list(jieba.cut(text)))
    }
    models = {
        'LogisticRegression': sklearn.linear_model.LogisticRegression(C = 1.2),
        'LinearSVC': sklearn.svm.LinearSVC(
            class_weight = 'balanced',
            C = 0.8,
            penalty = 'l2',
            loss = 'squared_hinge',
            dual = True,
            max_iter = 5000
        ),
        'SVC': sklearn.svm.SVC(
            kernel = 'rbf',
            C = 5,
            gamma = 'scale',
            class_weight = 'balanced'
        ),
        'NaiveBayes': sklearn.naive_bayes.MultinomialNB(),
        'DecisionTree': sklearn.tree.DecisionTreeClassifier(
            criterion = 'gini',
            class_weight = 'balanced',
            max_depth = None,
            min_samples_leaf = 2,
            ccp_alpha = 0,
        ),
        'RandomForest': sklearn.ensemble.RandomForestClassifier(
            n_estimators = 200,
            class_weight = 'balanced',
            max_depth = None
        ),
        'GradientBoosting': sklearn.ensemble.GradientBoostingClassifier(
            n_estimators = 200,
            learning_rate = 0.1,
            max_depth = 10,
            max_features = 'sqrt',
            min_samples_leaf = 10,
            subsample = 0.8
        )
    }
    train_comment, valid_comment, train_label, valid_label = read_dataset()
    metrics = []
    N = len(vectorizers.items()) * len(models.items())
    n = 0
    for vectorizer_name, vectorizer_function in vectorizers.items():
        for model_name, model_function in models.items():
            pipe = sklearn.pipeline.Pipeline(
                steps = [
                    ('vectorizer', vectorizer_function),
                    ('model', model_function)
                ]
            )
            pipe.fit(train_comment, train_label)
            train_prediction = pipe.predict(train_comment)
            valid_prediction = pipe.predict(valid_comment)
            metrics.append(
                {
                    'vectorizer': vectorizer_name,
                    'model': model_name,
                    'train': evaluate(train_label, train_prediction),
                    'valid': evaluate(valid_label, valid_prediction)
                }
            )
            progress_bar(n, N)
            n = n + 1
    df = []
    for metric in metrics:
        df.append(
            [
                metric['vectorizer'],
                metric['model'],
                metric['valid']['f1'],
                metric['train']['f1'],
                metric['valid']['accuracy'],
                metric['train']['accuracy'],
                metric['valid']['precision'],
                metric['train']['precision'],
                metric['valid']['recall'],
                metric['train']['recall'],
            ]
        )
    summary = pd.DataFrame(
        data = df,
        columns = [
            'vectorizer',
            'model',
            'valid-f1',
            'train-f1',
            'valid-accuracy',
            'train-accuracy',
            'valid-precision',
            'train-precision',
            'valid-recall',
            'train-recall'
        ]
    )
    summary = summary.sort_values(by = 'valid-f1', ascending = False)
    summary.to_csv('result.csv', index = False)
    print(summary)


def test() -> None:
    pipe = sklearn.pipeline.Pipeline(
        steps = [
            (
                'vectorizer', sklearn.feature_extraction.text.CountVectorizer(
                    tokenizer = lambda text: list(jieba.cut(text))
                )
            ),
            (
                'model', sklearn.ensemble.GradientBoostingClassifier(
                    n_estimators = 200,
                    learning_rate = 0.1,
                    max_depth = 10,
                    max_features = 'sqrt',
                    min_samples_leaf = 10,
                    subsample = 0.8
                )
            )
        ]
    )

    df_train = pd.read_csv(filepath_or_buffer = os.path.join('dataset', 'train.csv'), sep = '\t')
    train_comment = df_train['comment']
    train_label = df_train['label']

    pipe.fit(train_comment, train_label)

    df_test = pd.read_csv(filepath_or_buffer = os.path.join('dataset', 'test.csv'), sep = ',')
    test_id = df_test['id']
    test_comment = df_test['comment']

    prediction = pipe.predict(test_comment)

    submission = pd.DataFrame(
        data = {
            'id': test_id,
            'label': prediction
        }
    )
    submission.to_csv('submission.csv', index = False)
    print("======== done ========")



if __name__ == '__main__':
    train()
    test()